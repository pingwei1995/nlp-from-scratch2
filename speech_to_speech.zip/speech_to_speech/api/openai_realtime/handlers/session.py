from __future__ import annotations

import logging
from typing import Optional

from openai.types.realtime import (
    RealtimeErrorEvent,
    SessionCreatedEvent,
    SessionUpdatedEvent,
    SessionUpdateEvent,
)
from openai.types.realtime.realtime_transcription_session_create_request import (
    RealtimeTranscriptionSessionCreateRequest,
)

from speech_to_speech.api.openai_realtime.handlers.base import RealtimeBaseHandler

logger = logging.getLogger(__name__)


class SessionHandler(RealtimeBaseHandler):
    """Owns session lifecycle: config updates and lifecycle events."""

    def handle_session_update(self, conn_id: str, event: SessionUpdateEvent) -> Optional[RealtimeErrorEvent]:
        """Apply session config changes.

        Only ``RealtimeSessionCreateRequest`` sessions are accepted;
        ``RealtimeTranscriptionSessionCreateRequest`` sessions not yet supported.
        Incoming fields are deep-merged into the existing session so that
        partial updates preserve previously-set values.
        """
        s = event.session
        if s is None:
            return None

        if isinstance(s, RealtimeTranscriptionSessionCreateRequest):
            return self.make_error(
                message="Only 'realtime' session type is supported; transcription sessions are not.",
                _type="invalid_session_type",
            )

        transcription = s.audio.input.transcription if s.audio is not None and s.audio.input is not None else None
        if transcription is not None and isinstance(transcription.language, str):
            language = transcription.language.strip()
            if language.lower() == "auto":
                if not self._service.stt_auto_reset_supported:
                    return self.make_error(
                        message="Auto cannot reset the active STT backend's configured language hint.",
                        _type="invalid_request_error",
                    )
                transcription.language = "auto"
            else:
                if not language:
                    return self.make_error(message="Language must not be empty.", _type="invalid_request_error")
                for backend, supported in (
                    ("STT", self._service.stt_supported_languages),
                    ("TTS", self._service.tts_supported_languages),
                ):
                    if supported is not None and language not in supported:
                        return self.make_error(
                            message=f"Language {language!r} is not supported by the active {backend} backend.",
                            _type="invalid_request_error",
                        )
                transcription.language = language

        model = getattr(s, "model", None)
        if model is not None:
            logger.info(f"Session model set to: {model}")

        cfg = self._state(conn_id).runtime_config
        current = cfg.session
        if current is None:
            cfg.session = s
        else:
            cfg.apply_session_update(s)
        logger.info("Session configuration updated")
        return None

    def build_session_created(self, conn_id: str) -> SessionCreatedEvent:
        """Build a SessionCreatedEvent populated with the current config."""
        cfg = self._state(conn_id).runtime_config
        # The OpenAI GA protocol includes the session id in session.created.
        # The SDK model has no `id` field but allows extras, and model_dump()
        # carries them onto the wire.
        session = cfg.session.model_copy(update={"id": conn_id})
        return SessionCreatedEvent(
            type="session.created",
            event_id=self._next_event_id(),
            session=session,
        )

    def build_session_updated(self, conn_id: str) -> SessionUpdatedEvent:
        """Build a SessionUpdatedEvent populated with the current config.

        Sent after a successful session.update, per the OpenAI Realtime
        protocol: https://platform.openai.com/docs/api-reference/realtime-server-events/session/updated
        """
        cfg = self._state(conn_id).runtime_config
        session = cfg.session.model_copy(update={"id": conn_id})
        return SessionUpdatedEvent(
            type="session.updated",
            event_id=self._next_event_id(),
            session=session,
        )
